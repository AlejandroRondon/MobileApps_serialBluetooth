package BluetoothPackage_SE;

public interface InterfaceCommunication {
	public void receivedString(String received);
}
