package com.Serialbluetooth.serialbluetooth;

public interface InterfaceKeyboard {
	public void pressedKey(char charTosend);
	public void writtenString(String stringsTosend);
}
